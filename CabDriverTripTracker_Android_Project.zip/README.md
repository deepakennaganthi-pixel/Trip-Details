# Cab Driver Trip Tracker

Android app starter project for daily cab trip logging.

Features:
- Offline trip storage on the phone
- Date and pickup time
- Location/destination
- Optional booking/reference
- Automatic daily trip count
- Date-wise report
- CSV export that opens in Excel

## Build
Open this folder in Android Studio. Let Gradle sync, then choose:
Build > Build Bundle(s) / APK(s) > Build APK(s)

The generated debug APK will be under:
app/build/outputs/apk/debug/app-debug.apk

## Notes
This is a simple offline MVP. A production version can add driver/vehicle setup, date-range picker, weekly summaries, real XLSX export, backup/restore, editing/deleting trips, and admin PIN.

package com.example.cabdrivertriptracker

import android.app.*
import android.os.Bundle
import android.content.*
import android.graphics.Color
import android.view.*
import android.widget.*
import java.text.SimpleDateFormat
import java.util.*
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var list: LinearLayout
    private lateinit var count: TextView
    private val prefs by lazy { getSharedPreferences("trips", MODE_PRIVATE) }
    private val fmt = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
    private val display = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        showHome()
    }

    private fun showHome() {
        val root = LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val title=TextView(this).apply { text="Cab Driver Trip Tracker"; textSize=25f; setTextColor(Color.rgb(20,20,20)); setPadding(0,0,0,18) }
        root.addView(title)
        count=TextView(this).apply{textSize=19f; setPadding(0,0,0,18)}
        root.addView(count)
        val add=Button(this).apply{text="➕ Add Trip"; setOnClickListener{addTrip()}}
        root.addView(add)
        val report=Button(this).apply{text="📊 Monthly / Date-Range Report"; setOnClickListener{report()}}
        root.addView(report)
        val export=Button(this).apply{text="📥 Export CSV for Excel"; setOnClickListener{exportCsv()}}
        root.addView(export)
        val scroll=ScrollView(this); list=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}; scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1,0,1f))
        setContentView(root); refreshToday()
    }

    private fun data(): JSONArray = try { JSONArray(prefs.getString("data","[]")!!) } catch(e:Exception){JSONArray()}
    private fun save(a:JSONArray){prefs.edit().putString("data",a.toString()).apply()}

    private fun refreshToday(){
        list.removeAllViews()
        val today=fmt.format(Date()); val a=data(); var n=0
        for(i in 0 until a.length()){val o=a.getJSONObject(i); if(o.getString("date")==today){n++; val t=TextView(this).apply{text="${o.getString("time")} — ${o.getString("location")}";textSize=17f;setPadding(8,12,8,12)};list.addView(t)}}
        count.text="Today: $n trip(s) • ${display.format(Date())}"
    }

    private fun addTrip(){
        val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,8,24,8)}
        val time=EditText(this).apply{hint="Pickup time (e.g. 08:00 AM)"}
        val loc=EditText(this).apply{hint="Location / destination"}
        val ref=EditText(this).apply{hint="Booking / reference (optional)"}
        box.addView(time);box.addView(loc);box.addView(ref)
        AlertDialog.Builder(this).setTitle("Add today's trip").setView(box)
            .setNegativeButton("Cancel",null).setPositiveButton("Save"){_,_-> 
                if(loc.text.toString().trim().isEmpty()){Toast.makeText(this,"Please enter location",Toast.LENGTH_SHORT).show();return@setPositiveButton}
                val a=data(); a.put(JSONObject().apply{put("date",fmt.format(Date()));put("time",time.text.toString());put("location",loc.text.toString());put("reference",ref.text.toString())});save(a);refreshToday()
            }.show()
    }

    private fun report(){
        val a=data(); val by=sortedMapOf<String,MutableList<JSONObject>>()
        for(i in 0 until a.length()){val o=a.getJSONObject(i);by.getOrPut(o.getString("date")){mutableListOf()}.add(o)}
        val text=StringBuilder("DATE-WISE REPORT\n\n"); var total=0
        by.forEach{(d,items)-> total+=items.size;text.append("$d — ${items.size} trips\n");items.forEach{text.append("  ${it.getString("time")} — ${it.getString("location")}\n")};text.append("\n")}
        text.append("MONTH / RANGE TOTAL: $total trips")
        AlertDialog.Builder(this).setTitle("Trip Report").setMessage(text.toString()).setPositiveButton("Close",null).show()
    }

    private fun exportCsv(){
        val a=data(); val sb=StringBuilder("Date,Pickup Time,Location,Booking Reference\n")
        for(i in 0 until a.length()){val o=a.getJSONObject(i);sb.append(csv(o.getString("date"))).append(",").append(csv(o.getString("time"))).append(",").append(csv(o.getString("location"))).append(",").append(csv(o.getString("reference"))).append("\n")}
        val intent=Intent(Intent.ACTION_SEND).apply{type="text/csv";putExtra(Intent.EXTRA_SUBJECT,"Cab Trip Report");putExtra(Intent.EXTRA_TEXT,sb.toString())}
        startActivity(Intent.createChooser(intent,"Export report"))
    }
    private fun csv(s:String)= """+s.replace(""","""")+"""
}
